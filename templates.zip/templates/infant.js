document.querySelector("#open-popup1").addEventListener("click", function(){
    document.querySelector(".popup1").classList.add("active");
});

document.querySelector(".popup1 .close-btn1").addEventListener("click", function(){
    document.querySelector(".popup1").classList.remove("active");
});


document.querySelector("#open-popup2").addEventListener("click", function(){
    document.querySelector(".popup2").classList.add("active");
});

document.querySelector(".popup2 .close-btn2").addEventListener("click", function(){
    document.querySelector(".popup2").classList.remove("active");
});
document.querySelector("#open-popup3").addEventListener("click", function(){
    document.querySelector(".popup3").classList.add("active");
});

document.querySelector(".popup3 .close-btn3").addEventListener("click", function(){
    document.querySelector(".popup3").classList.remove("active");
});

document.querySelector("#open-popup4").addEventListener("click", function(){
    document.querySelector(".popup4").classList.add("active");
});

document.querySelector(".popup4 .close-btn4").addEventListener("click", function(){
    document.querySelector(".popup4").classList.remove("active");
});


document.querySelector("#open-popup5").addEventListener("click", function(){
    document.querySelector(".popup5").classList.add("active");
});

document.querySelector(".popup5 .close-btn5").addEventListener("click", function(){
    document.querySelector(".popup5").classList.remove("active");
});



document.querySelector("#open-popup6").addEventListener("click", function(){
    document.querySelector(".popup6").classList.add("active");
});

document.querySelector(".popup6 .close-btn6").addEventListener("click", function(){
    document.querySelector(".popup6").classList.remove("active");
});
document.querySelector("#open-popup7").addEventListener("click", function(){
    document.querySelector(".popup7").classList.add("active");
});

document.querySelector(".popup7 .close-btn7").addEventListener("click", function(){
    document.querySelector(".popup7").classList.remove("active");
});
document.querySelector("#open-popup8").addEventListener("click", function(){
    document.querySelector(".popup8").classList.add("active");
});

document.querySelector(".popup8 .close-btn8").addEventListener("click", function(){
    document.querySelector(".popup8").classList.remove("active");
});
document.querySelector("#open-popup9").addEventListener("click", function(){
    document.querySelector(".popup9").classList.add("active");
});

document.querySelector(".popup9 .close-btn9").addEventListener("click", function(){
    document.querySelector(".popup9").classList.remove("active");
});

document.querySelector("#open-popup10").addEventListener("click", function(){
    document.querySelector(".popup10").classList.add("active");
});

document.querySelector(".popup10 .close-btn10").addEventListener("click", function(){
    document.querySelector(".popup10").classList.remove("active");
});

document.querySelector("#open-popup11").addEventListener("click", function(){
    document.querySelector(".popup11").classList.add("active");
});

document.querySelector(".popup11 .close-btn11").addEventListener("click", function(){
    document.querySelector(".popup11").classList.remove("active");
});

document.querySelector("#open-popup12").addEventListener("click", function(){
    document.querySelector(".popup12").classList.add("active");
});

document.querySelector(".popup12 .close-btn12").addEventListener("click", function(){
    document.querySelector(".popup12").classList.remove("active");
});


